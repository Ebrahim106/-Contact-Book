
package project;

public class Project {

    public static void main(String[] args)  {
     MyFram m1=new MyFram();
     m1.setVisible(true);
   
    }
    
}
